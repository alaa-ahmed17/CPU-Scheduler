# OS_Project
<h3>CPU Scheduler</h3>
Simple CPU scheduler that implements RR, SJF, FTCF, MLFQ, and FCFS on proccesses using C programming language. Also the project works like a virtual monitor that shows the state of the proccess when running or issuing input/output. 

___________________________________________________________________________________________________________________________________________________________

<h4>Team members:</h4>

11-Alaa Ahmed Ibraheem

22-Zainab Ahmed Younis

24-Sayed Ibraheem Sayed

48-Mariam Medhat Mahmoud

54-Youmna Waleed Tawfeek
___________________________________________________________________________________________________________________________________________________________

<h1>ppp.c --> is the main code of the projeect!</h1>
